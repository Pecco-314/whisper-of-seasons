<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="乌鸦？？" tilewidth="16" tileheight="16" tilecount="36" columns="6">
 <image source="C:/Users/DELL/Desktop/乌鸦？？.png" width="100" height="100"/>
</tileset>
