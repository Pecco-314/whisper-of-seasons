<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Outside_Stuff_TILESET_B-C-D-E" tilewidth="16" tileheight="16" tilecount="2304" columns="48">
 <image source="D:/FileRecv/Outside_Stuff_TILESET_B-C-D-E.png" width="768" height="768"/>
</tileset>
