<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="1" tilewidth="16" tileheight="16" tilecount="224" columns="14">
 <image source="AnimTIles.png" width="224" height="256"/>
</tileset>
