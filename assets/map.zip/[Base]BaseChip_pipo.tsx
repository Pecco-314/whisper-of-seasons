<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="[Base]BaseChip_pipo" tilewidth="16" tileheight="16" tilecount="4256" columns="16">
 <image source="[Base]BaseChip_pipo.png" width="256" height="4256"/>
</tileset>
