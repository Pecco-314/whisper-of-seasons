<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="秋天草原-02_爱给网_aigei_com" tilewidth="16" tileheight="16" tilecount="576" columns="16">
 <image source="秋天草原-02_爱给网_aigei_com.png" width="256" height="576"/>
</tileset>
