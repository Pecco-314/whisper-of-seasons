<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Apple" tilewidth="16" tileheight="16" tilecount="68" columns="34">
 <image source="Apple.png" width="544" height="32"/>
</tileset>
