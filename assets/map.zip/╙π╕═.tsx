<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="鱼竿" tilewidth="16" tileheight="16" tilecount="324" columns="18">
 <image source="鱼竿.png" width="300" height="300"/>
</tileset>
